<?php
require_once 'includes/header.php';
require_admin();

/* ==============================
   FETCH TODAY'S CLASS SUMMARY
============================== */
$today = date('Y-m-d');
$today_summary_query = "
    SELECT 
        c.id as class_id,
        c.class_name,
        COUNT(DISTINCT s.id) as total_students,
        SUM(CASE WHEN a.period_1_status = 'present' OR a.period_2_status = 'present' THEN 1 ELSE 0 END) as present_count
    FROM classes c
    LEFT JOIN students s ON c.id = s.class_id
    LEFT JOIN attendance a ON s.id = a.student_id AND a.date = ?
    GROUP BY c.id, c.class_name
    ORDER BY c.class_name
";
$stmt_summary = $pdo->prepare($today_summary_query);
$stmt_summary->execute([$today]);
$today_classes = $stmt_summary->fetchAll();

/* ==============================
   FETCH FILTER DATA FOR DETAILED REPORT
============================== */
$classes = $pdo->query("SELECT * FROM classes ORDER BY class_name")->fetchAll();
$rooms   = $pdo->query("SELECT * FROM rooms ORDER BY room_name")->fetchAll();

$selected_class = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;
$selected_room  = isset($_GET['room_id']) ? (int)$_GET['room_id'] : 0;
$from_date      = isset($_GET['from_date']) ? $_GET['from_date'] : date('Y-m-01');
$to_date        = isset($_GET['to_date']) ? $_GET['to_date'] : date('Y-m-d');

$report_data = [];
$present_total = 0;
$absent_total  = 0;
$total_students = 0;

/* ==============================
   FETCH DETAILED REPORT DATA
============================== */
if ($selected_class > 0) {
    $query = "
        SELECT s.id, s.full_name,
               SUM(CASE WHEN a.period_1_status = 'present' THEN 1 ELSE 0 END) as p1_present,
               SUM(CASE WHEN a.period_2_status = 'present' THEN 1 ELSE 0 END) as p2_present,
               COUNT(DISTINCT a.date) as total_days
        FROM students s
        LEFT JOIN attendance a 
            ON s.id = a.student_id 
            AND a.date BETWEEN ? AND ?
        WHERE s.class_id = ?
    ";

    if ($selected_room > 0) {
        $query .= " AND s.room_id = ?";
    }

    $query .= " GROUP BY s.id, s.full_name ORDER BY s.full_name";
    $stmt = $pdo->prepare($query);
    $params = [$from_date, $to_date, $selected_class];
    if ($selected_room > 0) $params[] = $selected_room;

    $stmt->execute($params);
    $report_data = $stmt->fetchAll();
    $total_students = count($report_data);
}

/* ==============================
   CSV EXPORT
============================== */
if (isset($_GET['export']) && $_GET['export'] == 'csv' && !empty($report_data)) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="attendance_report.csv"');
    $output = fopen('php://output', 'w');
    fputcsv($output, ['Student Name', 'P1 Present', 'P2 Present', 'Attendance %']);

    foreach ($report_data as $row) {
        $total_possible = $row['total_days'] * 2;
        $student_present = $row['p1_present'] + $row['p2_present'];
        $perc = $total_possible > 0 ? round(($student_present / $total_possible) * 100) : 0;
        fputcsv($output, [$row['full_name'], $row['p1_present'], $row['p2_present'], $perc . '%']);
    }
    fclose($output);
    exit();
}
?>

<style>
/* Today's Summary Cards */
.today-title {
    font-size: 1.2rem;
    font-weight: 700;
    color: #4e73df;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}
.class-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 20px;
    margin-bottom: 40px;
}
.class-card {
    background: #fff;
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.05);
    border-left: 5px solid #4e73df;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}
.class-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.1);
}
.class-card.complete { border-left-color: #1cc88a; }
.class-card.partial { border-left-color: #f6c23e; }
.class-card.empty { border-left-color: #e74a3b; }

.class-card .class-name {
    font-size: 1.1rem;
    font-weight: 700;
    color: #333;
    margin-bottom: 15px;
    display: block;
}
.class-card .stats-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.class-card .stat-box {
    text-align: center;
}
.class-card .stat-value {
    font-size: 1.4rem;
    font-weight: 700;
    display: block;
}
.class-card .stat-label {
    font-size: 0.8rem;
    color: #888;
    text-transform: uppercase;
}
.class-card .percentage-badge {
    position: absolute;
    top: 15px;
    right: 15px;
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 700;
    color: #fff;
}
.bg-present { background: #1cc88a; }
.bg-absent { background: #e74a3b; }
.bg-warning { background: #f6c23e; }

/* General Styles */
.stat-cards{display:flex;gap:20px;margin-bottom:25px;flex-wrap:wrap;}
.stat-card{flex:1;min-width:220px;padding:25px;border-radius:12px;color:#fff;position:relative;transition:.4s;box-shadow:0 10px 25px rgba(0,0,0,.08);}
.stat-card:hover{transform:translateY(-6px);}
.stat-card i{font-size:30px;position:absolute;right:20px;top:20px;opacity:.3;}
.card-present{background:linear-gradient(45deg,#1cc88a,#17a673);}
.card-absent{background:linear-gradient(45deg,#e74a3b,#c0392b);}
.card-total{background:linear-gradient(45deg,#4e73df,#2e59d9);}
.stat-card h4{font-size:28px;margin:0;}
.stat-card p{margin:0;font-weight:600;}
.progress{background:#eaecf4;border-radius:6px;height:10px;}
.progress-bar{height:100%;border-radius:6px;transition:width .6s ease;}
</style>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Attendance Reports & Analytics</h1>
</div>

<!-- TODAY'S CLASS SUMMARY CARDS -->
<div class="today-title">
    <i class="fas fa-calendar-day"></i> XAALADDA FASALADA MAANTA (<?= date('d-M-Y') ?>)
</div>

<div class="class-grid">
    <?php foreach($today_classes as $tc): 
        $perc = $tc['total_students'] > 0 ? round(($tc['present_count'] / $tc['total_students']) * 100) : 0;
        $status_class = $perc == 100 ? 'complete' : ($perc > 0 ? 'partial' : 'empty');
        $badge_color = $perc == 100 ? 'bg-present' : ($perc > 0 ? 'bg-warning' : 'bg-absent');
    ?>
    <div class="class-card <?= $status_class ?>">
        <span class="percentage-badge <?= $badge_color ?>"><?= $perc ?>%</span>
        <span class="class-name"><?= htmlspecialchars($tc['class_name']) ?></span>
        <div class="stats-row">
            <div class="stat-box">
                <span class="stat-value" style="color: #1cc88a;"><?= $tc['present_count'] ?></span>
                <span class="stat-label">Joogta</span>
            </div>
            <div class="stat-box">
                <span class="stat-value" style="color: #e74a3b;"><?= $tc['total_students'] - $tc['present_count'] ?></span>
                <span class="stat-label">Maqan</span>
            </div>
            <div class="stat-box">
                <span class="stat-value" style="color: #4e73df;"><?= $tc['total_students'] ?></span>
                <span class="stat-label">Wadar</span>
            </div>
        </div>
        <div class="progress mt-3">
            <div class="progress-bar <?= $badge_color ?>" style="width: <?= $perc ?>%"></div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<hr class="mb-5">

<!-- DETAILED REPORT FILTER -->
<div class="today-title">
    <i class="fas fa-file-alt"></i> WARBIXIN FAAHFAAHSAN (DETAILED REPORT)
</div>

<div class="card mb-4">
<div class="card-body">
<form method="GET" class="row" style="display:flex;gap:15px;flex-wrap:wrap;align-items:flex-end;">

<div class="form-group">
<label>Class *</label>
<select name="class_id" class="form-control" required>
<option value="">Select Class</option>
<?php foreach($classes as $class): ?>
<option value="<?= $class['id']; ?>" <?= $selected_class==$class['id']?'selected':''; ?>>
<?= $class['class_name']; ?>
</option>
<?php endforeach; ?>
</select>
</div>

<div class="form-group">
<label>Room</label>
<select name="room_id" class="form-control">
<option value="">All Rooms</option>
<?php foreach($rooms as $room): ?>
<option value="<?= $room['id']; ?>" <?= $selected_room==$room['id']?'selected':''; ?>>
<?= $room['room_name']; ?>
</option>
<?php endforeach; ?>
</select>
</div>

<div class="form-group">
<label>From</label>
<input type="date" name="from_date" class="form-control" value="<?= $from_date; ?>">
</div>

<div class="form-group">
<label>To</label>
<input type="date" name="to_date" class="form-control" value="<?= $to_date; ?>">
</div>

<div class="form-group">
<button type="submit" class="btn btn-primary">Generate</button>
<?php if(!empty($report_data)): ?>
<a href="?<?= $_SERVER['QUERY_STRING']; ?>&export=csv" class="btn btn-success">Export CSV</a>
<?php endif; ?>
</div>

</form>
</div>
</div>

<?php if(!empty($report_data)): ?>

<?php
foreach ($report_data as $row) {
    $total_possible = $row['total_days'] * 2;
    $student_present = $row['p1_present'] + $row['p2_present'];
    $perc = $total_possible > 0 ? round(($student_present / $total_possible) * 100) : 0;
    if ($perc >= 50) $present_total++;
    else $absent_total++;
}
?>

<div class="stat-cards">
<div class="stat-card card-present">
<i class="fas fa-user-check"></i>
<p>Total Present</p>
<h4><?= $present_total; ?></h4>
</div>

<div class="stat-card card-absent">
<i class="fas fa-user-times"></i>
<p>Total Absent</p>
<h4><?= $absent_total; ?></h4>
</div>

<div class="stat-card card-total">
<i class="fas fa-users"></i>
<p>Total Students</p>
<h4><?= $total_students; ?></h4>
</div>
</div>

<div class="card">
<div class="card-header">
Attendance Summary: <?= $from_date; ?> → <?= $to_date; ?>
</div>

<div class="card-body">
<table class="table table-bordered">
<thead>
<tr>
<th>Student Name</th>
<th>P1</th>
<th>P2</th>
<th>Attendance %</th>
</tr>
</thead>
<tbody>

<?php foreach($report_data as $row): 
$total_possible = $row['total_days'] * 2;
$student_present = $row['p1_present'] + $row['p2_present'];
$perc = $total_possible > 0 ? round(($student_present / $total_possible) * 100) : 0;
$color = $perc==100 ? '#1cc88a' : ($perc>=50 ? '#f6c23e' : '#e74a3b');
?>

<tr>
<td><?= $row['full_name']; ?></td>
<td><?= $row['p1_present']; ?></td>
<td><?= $row['p2_present']; ?></td>
<td>
<div style="display:flex;align-items:center;gap:10px;">
<div class="progress" style="flex:1;">
<div class="progress-bar" style="width:<?= $perc; ?>%;background:<?= $color; ?>;"></div>
</div>
<strong><?= $perc; ?>%</strong>
</div>
</td>
</tr>

<?php endforeach; ?>

</tbody>
</table>
</div>
</div>

<?php elseif($selected_class > 0): ?>
<div class="alert alert-info">No attendance data found.</div>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
