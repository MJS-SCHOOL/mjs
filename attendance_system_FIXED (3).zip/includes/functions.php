<?php
// =====================================================================
// INFINITYFREE COOKIE FIX - Xalinta dhibaatada Cookie-ta
// =====================================================================
// Waa in la socodsiiyo KAHOR session_start()
// Waxay u shaqeysaa browser kastaa oo ay ku jiraan private mode
// =====================================================================

// 1. Habayn session settings si cookie-ta loo aqbalo browser kasta
ini_set('session.use_only_cookies', 0);
ini_set('session.use_trans_sid', 1);
ini_set('session.cookie_samesite', 'Lax');
ini_set('session.cookie_httponly', '1');
ini_set('session.gc_maxlifetime', 86400);
ini_set('session.cookie_lifetime', 0);

// 2. Dejin parameters-ka cookie-ta si sax ah
if (!headers_sent()) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}

// 3. Bilaw session
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// =====================================================================

// Default settings - Hubi in aan la beddelin settings jira
if (!isset($_SESSION['lang'])) {
    $_SESSION['lang'] = 'so';
}
if (!isset($_SESSION['theme'])) {
    $_SESSION['theme'] = 'light';
}

// Security: Generate CSRF token
function generate_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// Security: Verify CSRF token
function verify_csrf_token($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Security: Check if user is logged in
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

// Security: Check if user is admin
function is_admin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

// Security: Redirect if not logged in
function require_login() {
    if (!is_logged_in()) {
        header("Location: login.php");
        exit();
    }
}

// Security: Redirect if not admin
function require_admin() {
    require_login();
    if (!is_admin()) {
        header("Location: dashboard.php?error=unauthorized");
        exit();
    }
}

// Utility: Sanitize input
function sanitize($data) {
    if (is_array($data)) {
        return array_map('sanitize', $data);
    }
    $data = str_replace(chr(0), '', $data);
    $data = trim(strip_tags($data));
    return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}

// Utility: Format date
function format_date($date, $format = 'Y-m-d') {
    return date($format, strtotime($date));
}

// Language Translations
$translations = [
    'so' => [
        'today' => 'Maanta',
        'total' => 'Wadar',
        'present' => 'Joogta',
        'absent' => 'Maqan',
        'class' => 'Fasal',
        'room' => 'Qol',
        'students' => 'Ardayda',
        'attendance' => 'Imaanshaha',
        'dashboard' => 'Dashboard-ka',
        'reports' => 'Warbixinnada',
        'users' => 'Isticmaalayaasha',
        'profile' => 'Profile-ka',
        'logout' => 'Ka bax',
        'login' => 'Soo gal',
        'save' => 'Keydi',
        'cancel' => 'Jooji',
        'edit' => 'Wax ka beddel',
        'delete' => 'Tirtir',
        'search' => 'Raadi',
        'import' => 'Soo geli',
        'export' => 'Dhoofso',
        'success' => 'Guul',
        'error' => 'Khalad',
        'welcome' => 'Ku soo dhowow',
        'menu' => 'Menu-ga',
        'settings' => 'Settings-ka',
        'admin_dashboard' => 'Maamulka Sare',
        'manage_data' => 'Maamul Xogta',
        'language' => 'Luqadda',
        'theme' => 'Muuqaalka',
        'dark_mode' => 'Habeen',
        'light_mode' => 'Maalin',
        'english' => 'English',
        'somali' => 'Soomaali',
        'luuqadaha' => 'Luuqadaha',
        'muuqaalka' => 'Muuqaalka',
        'dark' => 'Madow',
        'light' => 'Iftiinsan',
        'toggle_language' => 'Bedel Luuqadaha',
        'toggle_theme' => 'Bedel Muuqaalka',
        'language_switched' => 'Luuqadaha waa la beddelay',
        'theme_switched' => 'Muuqaalka waa la beddelay',
        'arabic' => 'Carabi',
        'rooms_status' => 'Heerka Qolalka',
        'mark_attendance' => 'Calaamadee Imaanshaha',
        'update_attendance' => 'Cusboonaysii Imaanshaha',
        'attendance_report' => 'Warbixinta Imaanshaha',
        'teacher_pages' => 'Bogagga Macallimiinta'
    ],
    'en' => [
        'today' => 'Today',
        'total' => 'Total',
        'present' => 'Present',
        'absent' => 'Absent',
        'class' => 'Class',
        'room' => 'Room',
        'students' => 'Students',
        'attendance' => 'Attendance',
        'dashboard' => 'Dashboard',
        'reports' => 'Reports',
        'users' => 'Users',
        'profile' => 'Profile',
        'logout' => 'Logout',
        'login' => 'Login',
        'save' => 'Save',
        'cancel' => 'Cancel',
        'edit' => 'Edit',
        'delete' => 'Delete',
        'search' => 'Search',
        'import' => 'Import',
        'export' => 'Export',
        'success' => 'Success',
        'error' => 'Error',
        'welcome' => 'Welcome',
        'menu' => 'Menu',
        'settings' => 'Settings',
        'admin_dashboard' => 'Admin Dashboard',
        'manage_data' => 'Manage Data',
        'language' => 'Language',
        'theme' => 'Theme',
        'dark_mode' => 'Dark',
        'light_mode' => 'Light',
        'english' => 'English',
        'somali' => 'Somali',
        'arabic' => 'Arabic',
        'luuqadaha' => 'Language',
        'muuqaalka' => 'Theme',
        'dark' => 'Dark',
        'light' => 'Light',
        'toggle_language' => 'Toggle Language',
        'toggle_theme' => 'Toggle Theme',
        'language_switched' => 'Language switched',
        'theme_switched' => 'Theme switched',
        'rooms_status' => 'Rooms Status',
        'mark_attendance' => 'Mark Attendance',
        'update_attendance' => 'Update Attendance',
        'attendance_report' => 'Attendance Report',
        'teacher_pages' => 'Teacher Pages'
    ],
    'ar' => [
        'today' => 'اليوم',
        'total' => 'المجموع',
        'present' => 'حاضر',
        'absent' => 'غائب',
        'class' => 'فصل',
        'room' => 'غرفة',
        'students' => 'الطلاب',
        'attendance' => 'الحضور',
        'dashboard' => 'لوحة القيادة',
        'reports' => 'التقارير',
        'users' => 'المستخدمين',
        'profile' => 'الملف الشخصي',
        'logout' => 'تسجيل الخروج',
        'login' => 'تسجيل الدخول',
        'save' => 'حفظ',
        'cancel' => 'إلغاء',
        'edit' => 'تعديل',
        'delete' => 'حذف',
        'search' => 'بحث',
        'import' => 'استيراد',
        'export' => 'تصدير',
        'success' => 'نجاح',
        'error' => 'خطأ',
        'welcome' => 'أهلاً بك',
        'menu' => 'القائمة',
        'settings' => 'الإعدادات',
        'admin_dashboard' => 'لوحة تحكم المسؤول',
        'manage_data' => 'إدارة البيانات',
        'language' => 'اللغة',
        'theme' => 'المظهر',
        'dark_mode' => 'الوضع الليلي',
        'light_mode' => 'الوضع النهاري',
        'english' => 'الإنجليزية',
        'somali' => 'الصومالية',
        'arabic' => 'العربية',
        'luuqadaha' => 'اللغات',
        'muuqaalka' => 'المظهر',
        'dark' => 'داكن',
        'light' => 'فاتح',
        'toggle_language' => 'تغيير اللغة',
        'toggle_theme' => 'تغيير المظهر',
        'language_switched' => 'تم تغيير اللغة',
        'theme_switched' => 'تم تغيير المظهر',
        'rooms_status' => 'حالة الغرف',
        'mark_attendance' => 'تسجيل الحضور',
        'update_attendance' => 'تحديث الحضور',
        'attendance_report' => 'تقرير الحضور',
        'teacher_pages' => 'صفحات المعلمين'
    ]
];

// Helper to get translation
function __($key) {
    global $translations;
    $lang = $_SESSION['lang'] ?? 'so';
    return $translations[$lang][$key] ?? ($translations['en'][$key] ?? $key);
}
?>
