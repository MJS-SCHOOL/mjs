<?php
/**
 * Teacher Page Access Control Helper
 * This file provides functions to check if a teacher has access to specific pages
 * Include this file in pages that should be restricted based on admin settings
 */

/**
 * Check if current user (teacher) has access to a specific page
 * @param string $page_name The page filename (e.g., 'mark_attendance.php')
 * @param PDO $pdo Database connection object
 * @return bool True if user has access, false otherwise
 */
function has_teacher_page_access($page_name, $pdo) {
    // Admins always have access to all pages
    if (is_admin()) {
        return true;
    }
    
    // Check if user is logged in
    if (!is_logged_in()) {
        return false;
    }
    
    $user_id = $_SESSION['user_id'];
    
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM teacher_pages WHERE user_id = ? AND page_name = ?");
        $stmt->execute([$user_id, $page_name]);
        $count = $stmt->fetchColumn();
        
        return $count > 0;
    } catch (PDOException $e) {
        // If table doesn't exist or query fails, allow access (backward compatibility)
        return true;
    }
}

/**
 * Require teacher page access - redirect if not allowed
 * @param string $page_name The page filename (e.g., 'mark_attendance.php')
 * @param PDO $pdo Database connection object
 */
function require_teacher_page_access($page_name, $pdo) {
    if (!has_teacher_page_access($page_name, $pdo)) {
        header("Location: dashboard.php?error=page_not_allowed");
        exit();
    }
}

/**
 * Get all pages accessible by a teacher
 * @param int $user_id The teacher's user ID
 * @param PDO $pdo Database connection object
 * @return array Array of page names
 */
function get_teacher_accessible_pages($user_id, $pdo) {
    try {
        $stmt = $pdo->prepare("SELECT page_name FROM teacher_pages WHERE user_id = ? ORDER BY page_name");
        $stmt->execute([$user_id]);
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (PDOException $e) {
        // If table doesn't exist, return empty array
        return [];
    }
}

/**
 * Get all available pages for teachers
 * @return array Array of page_name => page_label pairs
 */
function get_available_teacher_pages() {
    return [
        'dashboard.php' => 'Dashboard',
        'dashboard_periods.php' => 'Imtixan La baabashay',
        'mark_attendance.php' => 'Mark Attendance',
        'update_attendance.php' => 'Update Attendance',
        'reports.php' => 'Reports',
        'attendance_report.php' => 'Attendance Report',
        'profile.php' => 'Profile',
        'rooms.php' => 'Rooms',
        'classes.php' => 'Classes',
        'students.php' => 'Students',
        'rooms_attendance_status.php' => 'Rooms Status (Red/Green)',
        'room_summary.php' => 'Room Summary'
    ];
}
?>
