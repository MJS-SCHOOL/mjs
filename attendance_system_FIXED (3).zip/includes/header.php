<?php
require_once 'db.php';
require_once 'functions.php';
require_once 'teacher_page_access.php';
require_login();

// Fetch settings
$stmt = $pdo->query("SELECT * FROM settings WHERE id = 1");
$settings = $stmt->fetch();
if (!$settings) {
    $settings = ['site_name' => "MO'ALIM JAMA PRIMARY AND SECONDARY SCHOOL", 'logo' => 'logo.png'];
}

$current_page = basename($_SERVER['PHP_SELF']);

// Function to check if a page should be shown in navigation
function should_show_page($page_name, $pdo) {
    if (is_admin()) {
        return true;
    }
    return has_teacher_page_access($page_name, $pdo);
}
?>
<!DOCTYPE html>
<html lang="so">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <meta name="description" content="School Attendance System - Manage student attendance efficiently">
    <meta name="theme-color" content="#4e73df">
    <title>MJS 2026</title>
    
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    

    


    <!-- Chart.js for Charts -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
    
    <style>
        /* Additional responsive tweaks */
        @media (max-width: 480px) {
            body {
                font-size: 13px;
            }
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar Navigation -->
        <nav id="sidebar">
            <div class="sidebar-header" style="text-align: center; padding: 20px; position: relative;">

                <?php 
                $logo_path = "assets/img/logo.png"; // Default Fallback
                if (!empty($settings['logo']) && $settings['logo'] !== 'logo.png') {
                    $saved_logo = "images/logo/" . $settings['logo'];
                    if (file_exists($saved_logo)) {
                        $logo_path = $saved_logo;
                    }
                }
                ?>
                <img src="<?php echo htmlspecialchars($logo_path); ?>" alt="Logo" style="max-width: 80px; margin: 0 auto 10px; display: block;">
                <h4 style="color: #fff; font-size: 1.2rem;"><?php echo $settings['site_name']; ?></h4>
            </div>

            <ul class="components">
                <?php if (should_show_page('dashboard.php', $pdo)): ?>
                <li class="<?php echo $current_page == 'dashboard.php' ? 'active' : ''; ?>">
                    <a href="dashboard.php">
                        <i class="fas fa-tachometer-alt"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <?php endif; ?>

                <?php if (is_admin()): ?>
                <li class="<?php echo $current_page == 'admin_dashboard.php' ? 'active' : ''; ?>">
                    <a href="admin_dashboard.php">
                        <i class="fas fa-crown"></i>
                        <span>Admin Dashboard</span>
                    </a>
                </li>
                <?php endif; ?>

                <?php if (should_show_page('dashboard_periods.php', $pdo)): ?>
                <li class="<?php echo $current_page == 'dashboard_periods.php' ? 'active' : ''; ?>">
                    <a href="dashboard_periods.php">
                        <i class="fas fa-chart-line"></i>
                        <span>Exam Disqualified </span>
                    </a>
                </li>
                <?php endif; ?>
                
                <?php if (is_admin()): ?>
                <?php if (should_show_page('rooms.php', $pdo)): ?>
                <li class="<?php echo $current_page == 'rooms.php' ? 'active' : ''; ?>">
                    <a href="rooms.php">
                        <i class="fas fa-door-open"></i>
                        <span>Rooms</span>
                    </a>
                </li>
                <?php endif; ?>

                <?php if (should_show_page('rooms_attendance_status.php', $pdo)): ?>
                <li class="<?php echo $current_page == 'rooms_attendance_status.php' ? 'active' : ''; ?>">
                    <a href="rooms_attendance_status.php">
                        <i class="fas fa-chart-pie"></i>
                        <span>Rooms Status</span>
                    </a>
                </li>
                <?php endif; ?>

                <?php if (should_show_page('room_summary.php', $pdo)): ?>
                <li class="<?php echo $current_page == 'room_summary.php' ? 'active' : ''; ?>">
                    <a href="room_summary.php">
                        <i class="fas fa-list"></i>
                        <span>Room Summary</span>
                    </a>
                </li>
                <?php endif; ?>

                <?php if (should_show_page('classes.php', $pdo)): ?>
                <li class="<?php echo $current_page == 'classes.php' ? 'active' : ''; ?>">
                    <a href="classes.php">
                        <i class="fas fa-chalkboard-teacher"></i>
                        <span>Classes</span>
                    </a>
                </li>
                <?php endif; ?>

                <?php if (should_show_page('students.php', $pdo)): ?>
                <li class="<?php echo $current_page == 'students.php' ? 'active' : ''; ?>">
                    <a href="students.php">
                        <i class="fas fa-user-graduate"></i>
                        <span>Students</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php endif; ?>
                
                <?php if (should_show_page('mark_attendance.php', $pdo)): ?>
                <li class="<?php echo $current_page == 'mark_attendance.php' ? 'active' : ''; ?>">
                    <a href="mark_attendance.php">
                        <i class="fas fa-check-circle"></i>
                        <span>Mark Attendance</span>
                    </a>
                </li>
                <?php endif; ?>
                
                <?php if (should_show_page('update_attendance.php', $pdo)): ?>
                <li class="<?php echo $current_page == 'update_attendance.php' ? 'active' : ''; ?>">
                    <a href="update_attendance.php">
                        <i class="fas fa-edit"></i>
                        <span>Update Attendance</span>
                    </a>
                </li>
                <?php endif; ?>
                
                <?php if (is_admin()): ?>
                <?php if (should_show_page('reports.php', $pdo)): ?>
                <li class="<?php echo $current_page == 'reports.php' ? 'active' : ''; ?>">
                    <a href="reports.php">
                        <i class="fas fa-chart-bar"></i>
                        <span>Reports</span>
                    </a>
                </li>
                <?php endif; ?>

                <?php if (should_show_page('attendance_report.php', $pdo)): ?>
                <li class="<?php echo $current_page == 'attendance_report.php' ? 'active' : ''; ?>">
                    <a href="attendance_report.php">
                        <i class="fas fa-file-pdf"></i>
                        <span>Attendance Report</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php endif; ?>
                
                <?php if (is_admin()): ?>
                <li class="<?php echo $current_page == 'users.php' ? 'active' : ''; ?>">
                    <a href="users.php">
                        <i class="fas fa-users-cog"></i>
                        <span>Users</span>
                    </a>
                </li>
                <li class="<?php echo $current_page == 'manage_teacher_pages.php' ? 'active' : ''; ?>">
                    <a href="manage_teacher_pages.php">
                        <i class="fas fa-lock"></i>
                        <span>Teacher Pages</span>
                    </a>
                </li>
                <li class="<?php echo $current_page == 'settings.php' ? 'active' : ''; ?>">
                    <a href="settings.php">
                        <i class="fas fa-cogs"></i>
                        <span>Settings</span>
                    </a>
                </li>
                <li class="<?php echo $current_page == 'import.php' ? 'active' : ''; ?>">
                    <a href="import.php">
                        <i class="fas fa-file-import"></i>
                        <span>Goordhow</span>
                    </a>
                </li>
                <li class="<?php echo $current_page == 'manage_data.php' ? 'active' : ''; ?>">
                    <a href="manage_data.php">
                        <i class="fas fa-trash-alt"></i>
                        <span>Manage Data</span>
                    </a>
                </li>
                <?php endif; ?>
                
                <?php if (should_show_page('profile.php', $pdo)): ?>
                <li class="<?php echo $current_page == 'profile.php' ? 'active' : ''; ?>">
                    <a href="profile.php">
                        <i class="fas fa-user-circle"></i>
                        <span>Profile</span>
                    </a>
                </li>
                <?php endif; ?>

                <li>
                    <a href="logout.php">
                        <i class="fas fa-sign-out-alt"></i>
                        <span>Logout</span>
                    </a>
                </li>

            </ul>
        </nav>

        <!-- Main Content Area -->
        <div id="content">
            <!-- Top Navigation Bar -->
            <nav class="navbar">
                <div class="container-fluid">
                    <button type="button" id="sidebarCollapse" class="btn btn-info" onclick="toggleSidebar(event)" style="cursor: pointer; pointer-events: auto; z-index: 1001;">
                        <i class="fas fa-align-left"></i>
                        <span>Menu</span>
                    </button>
                    <div class="user-info">
                        <span><?php echo __('welcome'); ?>, <strong><?php echo $_SESSION['full_name']; ?></strong></span>
                        <?php 
                        $profile_image = isset($_SESSION['profile_image']) ? $_SESSION['profile_image'] : 'default_profile.png';
                        $profile_path = "assets/img/default_profile.png"; // Default Fallback
                        if (!empty($profile_image) && $profile_image !== 'default_profile.png') {
                            $saved_profile = "images/profile_pics/" . $profile_image;
                            if (file_exists($saved_profile)) {
                                $profile_path = $saved_profile;
                            }
                        }
                        ?>
                        <img src="<?php echo htmlspecialchars($profile_path); ?>" alt="Profile" class="rounded-circle" width="35" height="35" style="object-fit: cover;">
                    </div>
                </div>
            </nav>
            
            <!-- Main Content Container -->
            <div class="main-content">
