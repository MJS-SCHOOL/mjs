<?php
// Database configuration
// Waxaad halkan ku bedelan kartaa xogta database-kaaga
define('DB_HOST', 'sql303.infinityfree.com'); // Bedel haddii loo baahdo
define('DB_USER', 'if0_38972519');      // Bedel haddii loo baahdo
define('DB_PASS', 'mulki2029Aaa');          // Bedel haddii loo baahdo
define('DB_NAME', 'if0_38972519_subax_final_attendence_imtixaan_danbe_2026'); // Bedel haddii loo baahdo

// Create connection
try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS);
    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    // Disable emulated prepared statements for better security
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

} catch(PDOException $e) {
    // Log error and show generic message to user
    error_log($e->getMessage());
    die("Xiriirka xogta waa uu fashilmay. Fadlan isku day mar kale.");
}
?>
