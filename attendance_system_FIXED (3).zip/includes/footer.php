            </div> <!-- End of main-content -->
        </div> <!-- End of content -->
    </div> <!-- End of wrapper -->

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- Custom JS -->
    <script src="assets/js/main.js"></script>
    
    <!-- Sidebar Toggle Script - BULLETPROOF VERSION -->
    <script>
        // Global functions for sidebar toggle
        function toggleSidebar(event) {
            if (event) {
                event.preventDefault();
                event.stopPropagation();
            }
            const sidebar = document.getElementById('sidebar');
            if (sidebar) {
                sidebar.classList.toggle('active');
                console.log('Sidebar toggled - Active:', sidebar.classList.contains('active'));
            }
        }

        function closeSidebar(event) {
            if (event) {
                event.preventDefault();
                event.stopPropagation();
            }
            const sidebar = document.getElementById('sidebar');
            if (sidebar) {
                sidebar.classList.remove('active');
                console.log('Sidebar closed');
            }
        }

        function openSidebar(event) {
            if (event) {
                event.preventDefault();
                event.stopPropagation();
            }
            const sidebar = document.getElementById('sidebar');
            if (sidebar) {
                sidebar.classList.add('active');
                console.log('Sidebar opened');
            }
        }

        // Initialize sidebar handlers when DOM is ready
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.getElementById('sidebar');
            const sidebarBtn = document.getElementById('sidebarCollapse');

            if (sidebar && sidebarBtn) {
                // Button click handler
                sidebarBtn.addEventListener('click', toggleSidebar, true);
                sidebarBtn.addEventListener('touchend', toggleSidebar, true);

                // Close sidebar when clicking outside on mobile
                document.addEventListener('click', function(e) {
                    if (window.innerWidth < 768) {
                        const isClickInsideSidebar = sidebar.contains(e.target);
                        const isClickOnButton = sidebarBtn.contains(e.target);
                        
                        if (!isClickInsideSidebar && !isClickOnButton && sidebar.classList.contains('active')) {
                            closeSidebar();
                        }
                    }
                }, true);

                // Close sidebar when clicking on links (mobile only)
                const sidebarLinks = sidebar.querySelectorAll('a');
                sidebarLinks.forEach(link => {
                    link.addEventListener('click', function(e) {
                        if (window.innerWidth < 768) {
                            closeSidebar();
                        }
                    });
                });

                console.log('Sidebar handlers initialized successfully');
            } else {
                console.warn('Sidebar or button element not found');
            }
        });

        // Also initialize immediately in case DOMContentLoaded already fired
        if (document.readyState === 'loading') {
            // DOM is still loading
        } else {
            // DOM is already loaded
            const sidebar = document.getElementById('sidebar');
            const sidebarBtn = document.getElementById('sidebarCollapse');
            if (sidebar && sidebarBtn) {
                sidebarBtn.addEventListener('click', toggleSidebar, true);
                sidebarBtn.addEventListener('touchend', toggleSidebar, true);
                console.log('Sidebar handlers initialized immediately');
            }
        }
    </script>
</body>
</html>
