<?php
require_once 'includes/header.php';

// Today's date
$today = date('Y-m-d');

// Get filter values from GET parameters
$filter_date = isset($_GET['filter_date']) ? $_GET['filter_date'] : $today;
$filter_subject = isset($_GET['filter_subject']) ? $_GET['filter_subject'] : 'all';

// Function to split class and section (e.g., "6A" -> ["class" => "6", "section" => "A"])
function splitClassSection($fullName) {
    if (preg_match('/^(.+)([A-Za-z])$/', $fullName, $matches)) {
        return ['class' => $matches[1], 'section' => $matches[2]];
    }
    return ['class' => $fullName, 'section' => '-'];
}

// Fetch overview statistics based on role
if (is_admin()) {
    // Total counts (Static for overview)
    $total_students = $pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();
    $total_rooms = $pdo->query("SELECT COUNT(*) FROM rooms")->fetchColumn();
    $total_classes = $pdo->query("SELECT COUNT(*) FROM classes")->fetchColumn();
    
    // Build where clause for dynamic stats
    $where_clause = "1=1";
    $params = [];
    
    if ($filter_date && $filter_date != 'all') {
        $where_clause .= " AND a.date = ?";
        $params[] = $filter_date;
    }
    
    $where_clause_with_subject = $where_clause;
    $params_with_subject = $params;
    
    if ($filter_subject && $filter_subject != 'all') {
        $where_clause_with_subject .= " AND (a.period_1_subject = ? OR a.period_2_subject = ?)";
        $params_with_subject[] = $filter_subject;
        $params_with_subject[] = $filter_subject;
    }

    // Dynamic present count based on filters
    $present_stmt = $pdo->prepare("SELECT COUNT(*) FROM attendance a WHERE $where_clause_with_subject AND (a.period_1_status = 'present' OR a.period_2_status = 'present')");
    $present_stmt->execute($params_with_subject);
    $present_count = $present_stmt->fetchColumn();

    // Data for charts (Attendance by Class)
    $chart_stmt = $pdo->prepare("
        SELECT c.class_name, 
               COUNT(DISTINCT a.id) as present_count,
               (SELECT COUNT(*) FROM students s2 WHERE s2.class_id = c.id) as total_students
        FROM classes c
        LEFT JOIN students s ON c.id = s.class_id
        LEFT JOIN attendance a ON s.id = a.student_id AND $where_clause_with_subject AND (a.period_1_status = 'present' OR a.period_2_status = 'present')
        GROUP BY c.id
    ");
    $chart_stmt->execute($params_with_subject);
    $class_attendance_data = $chart_stmt->fetchAll();

    // ==============================================================================
    // DATA PREPARATION FOR THE NEW 5-DAY ATTENDANCE TABLE (ADMIN ONLY)
    // ==============================================================================
    
    // 1. Fetch the last 5 distinct dates where attendance was recorded
    $dates_stmt = $pdo->query("SELECT DISTINCT date FROM attendance ORDER BY date DESC LIMIT 5");
    $last_5_days = $dates_stmt->fetchAll(PDO::FETCH_COLUMN);
    sort($last_5_days); // Sort oldest to newest for chronological display (left to right)

    // 2. Fetch main data: Room, Class, and Total Students
    $query = "
        SELECT 
            r.id AS room_id,
            r.room_name AS room, 
            c.id AS class_id,
            c.class_name AS class, 
            COUNT(DISTINCT s.id) AS total_students
        FROM rooms r
        JOIN students s ON r.id = s.room_id
        JOIN classes c ON s.class_id = c.id
        GROUP BY r.id, c.id
        ORDER BY r.room_name, c.class_name
    ";
    $main_data = $pdo->query($query)->fetchAll(PDO::FETCH_ASSOC);

    // 3. Fetch attendance records for those 5 days securely
    $att_map = [];
    if (!empty($last_5_days)) {
        $placeholders = implode(',', array_fill(0, count($last_5_days), '?'));
        
        $att_query = "
            SELECT 
                s.room_id, 
                s.class_id, 
                a.date,
                SUM(CASE WHEN a.period_1_status = 'present' OR a.period_2_status = 'present' THEN 1 ELSE 0 END) as present_count,
                SUM(CASE WHEN a.period_1_status = 'absent' OR a.period_2_status = 'absent' THEN 1 ELSE 0 END) as absent_count
            FROM attendance a
            JOIN students s ON a.student_id = s.id
            WHERE a.date IN ($placeholders)
            GROUP BY s.room_id, s.class_id, a.date
        ";
        
        $att_stmt = $pdo->prepare($att_query);
        $att_stmt->execute($last_5_days);
        $att_data = $att_stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Map data for easy retrieval in the table loop
        foreach ($att_data as $row) {
            $att_map[$row['room_id']][$row['class_id']][$row['date']] = [
                'P' => $row['present_count'],
                'A' => $row['absent_count']
            ];
        }
    }
    
} else {
    // ==============================================================================
    // TEACHER / USER DASHBOARD LOGIC
    // ==============================================================================
    $user_id = $_SESSION['user_id'];
    
    // Total students in assigned rooms
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM students WHERE room_id IN (SELECT room_id FROM user_rooms WHERE user_id = ?)");
    $stmt->execute([$user_id]);
    $total_students = $stmt->fetchColumn();
    
    // Total rooms assigned to this user
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM user_rooms WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $total_rooms = $stmt->fetchColumn();
    
    // Total classes linked to assigned rooms
    $stmt = $pdo->prepare("SELECT COUNT(DISTINCT class_id) FROM rooms_classes WHERE room_id IN (SELECT room_id FROM user_rooms WHERE user_id = ?)");
    $stmt->execute([$user_id]);
    $total_classes = $stmt->fetchColumn();
    
    // Present count in assigned rooms
    $stmt = $pdo->prepare("
        SELECT COUNT(*) 
        FROM attendance a
        JOIN students s ON a.student_id = s.id
        WHERE a.date = ? 
        AND (a.period_1_status = 'present' OR a.period_2_status = 'present')
        AND s.room_id IN (SELECT room_id FROM user_rooms WHERE user_id = ?)
    ");
    $stmt->execute([$filter_date, $user_id]);
    $present_count = $stmt->fetchColumn();
    
    // Data for charts
    $chart_stmt = $pdo->prepare("
        SELECT c.class_name, 
               COUNT(a.id) as present_count,
               (SELECT COUNT(*) FROM students s2 WHERE s2.class_id = c.id AND s2.room_id IN (SELECT room_id FROM user_rooms WHERE user_id = ?)) as total_students
        FROM classes c
        JOIN students s ON c.id = s.class_id
        LEFT JOIN attendance a ON s.id = a.student_id AND a.date = ? AND (a.period_1_status = 'present' OR a.period_2_status = 'present')
        WHERE s.room_id IN (SELECT room_id FROM user_rooms WHERE user_id = ?)
        GROUP BY c.id
    ");
    $chart_stmt->execute([$user_id, $filter_date, $user_id]);
    $class_attendance_data = $chart_stmt->fetchAll();
}

$attendance_percentage = $total_students > 0 ? round(($present_count / $total_students) * 100, 1) : 0;

// Prepare Chart JS Data
$class_labels = [];
$class_data = [];
foreach ($class_attendance_data as $row) {
    $class_labels[] = $row['class_name'];
    $perc = $row['total_students'] > 0 ? round(($row['present_count'] / $row['total_students']) * 100, 1) : 0;
    $class_data[] = $perc;
}
?>

<style>
/* ============================================
   GLOBAL DASHBOARD STYLES
   ============================================ */
:root {
    --primary: #4e73df;
    --primary-light: #6c8bff;
    --primary-dark: #2e5cb8;
    --success: #1cc88a;
    --danger: #e74a3b;
    --warning: #f6ad55;
    --dark: #2e3338;
    --light: #f8f9fa;
    --border-radius: 20px;
    --shadow-sm: 0 2px 8px rgba(0, 0, 0, 0.08);
    --shadow-md: 0 8px 24px rgba(0, 0, 0, 0.12);
    --shadow-lg: 0 16px 48px rgba(0, 0, 0, 0.15);
    --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

/* Dashboard Cards Grid */
.dashboard-cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

/* Stat Card Styles */
.stat-card {
    border-radius: var(--border-radius);
    padding: 25px;
    color: #fff;
    position: relative;
    overflow: hidden;
    transition: var(--transition);
    box-shadow: var(--shadow-md);
}

.stat-card:hover {
    transform: translateY(-10px);
    box-shadow: var(--shadow-lg);
}

.stat-card::before {
    content: '';
    position: absolute;
    top: 0;
    right: 0;
    width: 100px;
    height: 100px;
    opacity: 0.1;
    border-radius: 50%;
    animation: pulse 3s ease-in-out infinite;
}

.stat-icon {
    font-size: 35px;
    opacity: 0.3;
    position: absolute;
    right: 20px;
    top: 20px;
    animation: float 3s ease-in-out infinite;
}

.stat-title {
    font-size: 15px;
    text-transform: uppercase;
    font-weight: 800;
    color: #ffffff;
    text-shadow: 0 0 5px rgba(255, 255, 255, 0.3);
    margin-bottom: 10px;
}

.stat-value {
    font-size: 36px;
    font-weight: 900;
    margin-top: 10px;
    color: #ffffff;
    text-shadow: 0 0 10px rgba(255, 255, 255, 0.5);
    position: relative;
    z-index: 1;
}

.stat-subtitle {
    font-size: 12px;
    opacity: 0.9;
    margin-top: 8px;
    position: relative;
    z-index: 1;
}

/* Color Variants */
.bg-blue { background: linear-gradient(135deg, #4e73df, #224abe); }
.bg-green { background: linear-gradient(135deg, #1cc88a, #13855c); }
.bg-orange { background: linear-gradient(135deg, #f6c23e, #dda20a); }
.bg-purple { background: linear-gradient(135deg, #6f42c1, #4e2c91); }

/* Animations */
@keyframes float {
    0% { transform: translateY(0px); }
    50% { transform: translateY(-5px); }
    100% { transform: translateY(0px); }
}

@keyframes pulse {
    0%, 100% { transform: scale(1); opacity: 0.1; }
    50% { transform: scale(1.1); opacity: 0.15; }
}

/* ============================================
   NEW MODERN TABLE STYLES (5 DAYS ATTENDANCE)
   ============================================ */
.modern-table-wrapper {
    background: #ffffff;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
    overflow: hidden;
    margin-bottom: 40px;
    border: 1px solid #e3e6f0;
}
.modern-table-header {
    background: linear-gradient(135deg, #4e73df 0%, #2e5cb8 100%);
    color: white;
    padding: 20px 25px;
    font-weight: 700;
    font-size: 1.1rem;
    display: flex;
    align-items: center;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
.table-responsive-custom {
    overflow-x: auto;
}
.modern-table {
    width: 100%;
    border-collapse: collapse;
    white-space: nowrap;
}
.modern-table thead th {
    background-color: #f8f9fc;
    color: #4a5568;
    font-size: 0.85rem;
    font-weight: 800;
    text-transform: uppercase;
    padding: 18px 20px;
    border-bottom: 2px solid #e2e8f0;
    text-align: center;
}
.modern-table tbody td {
    padding: 15px 20px;
    vertical-align: middle;
    border-bottom: 1px solid #edf2f7;
    color: #4a5568;
    font-weight: 500;
    text-align: center;
    transition: background-color 0.2s;
}
.modern-table tbody tr:hover td {
    background-color: #f8fafc;
}

/* Highlight Columns */
.col-room { color: #2e5cb8; font-weight: 700 !important; text-align: left !important; }
.col-class { color: #2d3748; font-weight: 700 !important; }
.col-section { color: #718096; }
.col-total { font-weight: 800 !important; font-size: 1.1rem; color: #4e73df; }

/* Badges for Present and Absent */
.att-badge-container {
    display: flex;
    justify-content: center;
    gap: 8px;
}
.badge-pa {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 0.8rem;
    font-weight: 700;
    min-width: 45px;
}
.b-present {
    background-color: #e6fffa;
    color: #047857;
    border: 1px solid #a7f3d0;
}
.b-absent {
    background-color: #fef2f2;
    color: #b91c1c;
    border: 1px solid #fecaca;
}
.b-empty {
    background-color: #f1f5f9;
    color: #94a3b8;
    border: 1px dashed #cbd5e1;
}

/* Responsive */
@media (max-width: 768px) {
    .dashboard-cards {
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: 15px;
    }
    .stat-card {
        padding: 20px;
    }
}
</style>

<?php if (!is_admin()): ?>
<div class="card" style="border-left: 5px solid #f6c23e; background: #fffbea; margin-bottom: 30px;">
    <div class="card-header" style="background: #f6c23e; color: #333; font-weight: bold; font-size: 1.1rem; padding: 15px;">
        <i class="fas fa-info-circle" style="margin-right: 10px;"></i>
        WARGILIN MUHIIM AH 
    </div>
    <div class="card-body" style="padding: 20px; line-height: 1.8; font-size: 0.95rem;">
        
        <div style="margin-bottom: 25px; padding-bottom: 20px; border-bottom: 2px solid #e3e6f0;">
            <h4 style="color: #4e73df; font-weight: bold; margin-bottom: 10px; font-size: 1.05rem;">
                <i class="fas fa-calendar-check" style="margin-right: 8px;"></i>
                1. XAADIRINТА MAALINLAHA 
            </h4>
            <p style="margin: 10px 0; color: #333;">
                <strong>Taariikhda Xaadirinта:</strong> Xulashada taariikhda waa muhiimada xaadirka maalin kasta si loo xaqiijiyo kala shaandheenta ardayda iyo xaadirka. 
            </p>
            <p style="margin: 10px 0; color: #333;">
                <strong>Fiiro gaar ah:</strong>Fadlan barre hubi oo xaqiiji in taarikhda kuu xulan in ay tahay taariikhda maanta oo sax ah.
            </p>
            <p style="margin: 10px 0; color: #d63384; font-weight: bold;">
                ⚠️ TAARIIKH KHADLAN XOG QALDAN!
            </p>
        </div>

        <div style="margin-bottom: 25px; padding-bottom: 20px; border-bottom: 2px solid #e3e6f0;">
            <h4 style="color: #4e73df; font-weight: bold; margin-bottom: 10px; font-size: 1.05rem;">
                <i class="fas fa-clock" style="margin-right: 8px;"></i>
                2. LABADA IMTIXAAN MAALINLAHA
            </h4>
            <div style="background: #e7f3ff; padding: 15px; border-radius: 5px; margin-bottom: 15px;">
                <p style="margin: 0; color: #004085; font-weight: bold;">
                    <i class="fas fa-hourglass-start" style="margin-right: 8px;"></i> IMTIXAAN 1AAD (PERIOD 1)
                </p>
                <p style="margin: 10px 0 0 0; color: #333;">Taariikhda, Room ka iyo Maadadda waa qasab in si sax ah loo xushaa maalin karta iyadoo lagu saleynaaayo hadba roomka lajoogo, xisada 2aad waa mid xayiran mana ahan suuragal in la xaadiriyo ilaa laga xaadiriyo xisada 1aad, sdiaa awgeed fadlan xaadiri xisada 1aad si sax ah.</p>
            </div>
            <div style="background: #f0e7ff; padding: 15px; border-radius: 5px; margin-bottom: 15px;">
                <p style="margin: 0; color: #5a0080; font-weight: bold;">
                    <i class="fas fa-hourglass-end" style="margin-right: 8px;"></i> IMTIXAAN 2AAD (PERIOD 2)
                </p>
                <p style="margin: 10px 0 0 0; color: #333;">Xisada 2aad waxa ay kuu furmi doontaa marka xisada 1aad la xaadiriyo, waana muhiim in la raaco talaaboyinkii saxda ahaa ee hubinta taariikhda roomla maadadda iyo keedinta</p>
            </div>
        </div>

        <div style="background: #f8f9fc; padding: 15px; border-radius: 5px; border-left: 4px solid #4e73df;">
            <h4 style="color: #4e73df; font-weight: bold; margin-bottom: 10px;">
                <i class="fas fa-info-circle" style="margin-right: 8px;"></i> GABO GABO
            </h4>
            <p style="margin: 10px 0; color: #333;">
                Maado kasta oo la xaadiriyo system ka waxy ka bixidoontaa si otomaticaal ah, waxaana kaliya aad arki doontaa maadooyinka harsan ama dhiman ee aan wali imtixaankooda la galin ama la xaadirin. Macalin waad ku mahadsantahay dadaalka iyo dhiirnatda joogtada ah guuleyso. 
            </p>
        </div>

    </div>
</div>
<?php endif; ?>

<?php if (is_admin()): ?>
<div class="dashboard-cards">
    <div class="stat-card bg-blue">
        <i class="fas fa-user-graduate stat-icon"></i>
        <div class="stat-title">Total Students</div>
        <div class="stat-value"><?php echo $total_students; ?></div>
        <div class="stat-subtitle">Ardayda Guud</div>
    </div>

    <div class="stat-card bg-green">
        <i class="fas fa-door-open stat-icon"></i>
        <div class="stat-title">Total Rooms</div>
        <div class="stat-value"><?php echo $total_rooms; ?></div>
        <div class="stat-subtitle">Qololka Guud</div>
    </div>

    <div class="stat-card bg-orange">
        <i class="fas fa-school stat-icon"></i>
        <div class="stat-title">Total Classes</div>
        <div class="stat-value"><?php echo $total_classes; ?></div>
        <div class="stat-subtitle">Fasalada Guud</div>
    </div>

    <div class="stat-card bg-purple">
        <i class="fas fa-chart-pie stat-icon"></i>
        <div class="stat-title">Today's Attendance %</div>
        <div class="stat-value"><?php echo $attendance_percentage; ?>%</div>
        <div class="stat-subtitle">Maanta Joogta</div>
    </div>
</div>

<div class="modern-table-wrapper">
    <div class="modern-table-header">
        <i class="fas fa-calendar-alt mr-3" style="margin-right: 12px; font-size: 1.4rem;"></i>
        Xogta Xaadirinta 5-tii Maalmood ee Ugu Dambeysay
    </div>
    
    <div class="table-responsive-custom">
        <table class="modern-table">
            <thead>
                <tr>
                    <th style="text-align: left;">Room</th>
                    <th>Class</th>
                    <th>Section</th>
                    <th>Total Students</th>
                    <?php if (empty($last_5_days)): ?>
                        <th>Maalmo Xaadirin Lama Hayo</th>
                    <?php else: ?>
                        <?php foreach ($last_5_days as $date): ?>
                            <th><?php echo date('d M Y', strtotime($date)); ?></th>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($main_data)): ?>
                    <tr>
                        <td colspan="<?php echo 4 + count($last_5_days); ?>" style="padding: 40px; text-align: center; color: #a0aec0;">
                            <i class="fas fa-folder-open mb-3" style="font-size: 2rem; display: block;"></i>
                            Xogta fasalada iyo ardayda wali lama diiwaangelin.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($main_data as $row): ?>
                        <?php 
                            $classInfo = splitClassSection($row['class']);
                        ?>
                        <tr>
                            <td class="col-room">
                                <i class="fas fa-door-open mr-2" style="color: #a0aec0;"></i> 
                                <?php echo htmlspecialchars($row['room']); ?>
                            </td>
                            <td class="col-class"><?php echo htmlspecialchars($classInfo['class']); ?></td>
                            <td class="col-section">
                                <span style="background: #edf2f7; padding: 3px 10px; border-radius: 20px; font-weight: 700;">
                                    <?php echo htmlspecialchars($classInfo['section']); ?>
                                </span>
                            </td>
                            <td class="col-total"><?php echo $row['total_students']; ?></td>
                            
                            <?php foreach ($last_5_days as $date): ?>
                                <td>
                                    <?php 
                                        $p_count = 0;
                                        $a_count = 0;
                                        $has_data = false;

                                        if (isset($att_map[$row['room_id']][$row['class_id']][$date])) {
                                            $p_count = $att_map[$row['room_id']][$row['class_id']][$date]['P'];
                                            $a_count = $att_map[$row['room_id']][$row['class_id']][$date]['A'];
                                            $has_data = true;
                                        }
                                    ?>
                                    
                                    <div class="att-badge-container">
                                        <?php if ($has_data): ?>
                                            <span class="badge-pa b-present" title="Present (Joogay)">
                                                P: <?php echo $p_count; ?>
                                            </span>
                                            <span class="badge-pa b-absent" title="Absent (Maqan)">
                                                A: <?php echo $a_count; ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge-pa b-empty">-</span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="row two-col" style="margin-top: 20px;">
    <div class="card">
        <div class="card-header">
            <span>FASALADA (%)</span>
        </div>
        <div class="card-body">
            <div style="position: relative; height: 300px;">
                <canvas id="classChart"></canvas>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-header">
            <span>Xaalada Maanta</span>
        </div>
        <div class="card-body">
            <div style="position: relative; height: 300px; display: flex; justify-content: center; align-items: center;">
                <canvas id="overviewPie" style="max-width: 250px;"></canvas>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Bar Chart - Attendance by Class
    const ctxBar = document.getElementById('classChart');
    if (ctxBar) {
        new Chart(ctxBar, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($class_labels); ?>,
                datasets: [{
                    label: 'Fasalada %',
                    data: <?php echo json_encode($class_data); ?>,
                    backgroundColor: '#4e73df',
                    borderRadius: 5,
                    borderSkipped: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: true, position: 'top' }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            callback: function(value) { return value + '%'; }
                        }
                    }
                }
            }
        });
    }

    // Pie Chart - Today's Overview
    const ctxPie = document.getElementById('overviewPie');
    if (ctxPie) {
        new Chart(ctxPie, {
            type: 'doughnut',
            data: {
                labels: ['Present', 'Absent'],
                datasets: [{
                    data: [<?php echo $present_count; ?>, <?php echo $total_students - $present_count; ?>],
                    backgroundColor: ['#1cc88a', '#e74a3b'],
                    borderColor: '#fff',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom' }
                }
            }
        });
    }
});
</script>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>